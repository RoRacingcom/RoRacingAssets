--!strict

-- Anticollide.lua by VanillaEdge
-- Parent this script to ServerScriptService, done :D

local CollectionService = game:GetService("CollectionService")
local PhysicsService = game:GetService("PhysicsService")
local Players = game:GetService("Players")

local playerGroupName = "Players"
local vehicleGroupName = "Vehicles"
local defaultGroupName = "Default"

PhysicsService:RegisterCollisionGroup(playerGroupName)
PhysicsService:RegisterCollisionGroup(vehicleGroupName)

PhysicsService:CollisionGroupSetCollidable(playerGroupName, vehicleGroupName, false)
PhysicsService:CollisionGroupSetCollidable(playerGroupName, playerGroupName, false)
PhysicsService:CollisionGroupSetCollidable(vehicleGroupName, vehicleGroupName, false)

-- Functions
local function toggleCollisions(model: Model, groupName: string)
	local function setCollisionGroup(instance: Instance)
		if not instance:IsA("BasePart") then return end
		instance.CollisionGroup = groupName
	end
	
	for _, instance in model:GetDescendants() do
		setCollisionGroup(instance)
	end
	
	model.DescendantAdded:Connect(setCollisionGroup)
end

local function onDescendantAdded(descendant: Instance)
	if descendant.Name ~= "A-Chassis Interface" then return end
	
	local carModel = descendant.Parent and descendant.Parent.Parent
	if not carModel or not carModel:IsA("Model") then return end
	
	toggleCollisions(carModel, vehicleGroupName)
end

local function onPlayerAdded(player: Player)
	player.CharacterAdded:Connect(function(character: Model)
		toggleCollisions(character, playerGroupName)
	end)

	if player.Character then
		toggleCollisions(player.Character, playerGroupName)
	end
end

-- Connections
workspace.DescendantAdded:Connect(onDescendantAdded)
Players.PlayerAdded:Connect(onPlayerAdded)

-- Initialise
for _, player in Players:GetPlayers() do
	onPlayerAdded(player)
end

for _, descendant in workspace:GetDescendants() do
	onDescendantAdded(descendant)
end
