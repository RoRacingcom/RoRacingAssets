-- Heavily modified version of standard anticollide by chedsapp
-- Updated by Vanilla to work with new features
-- This script does not work with older anticollide scripts, no need for the workspace script as well.

local PhysicsService = game:GetService("PhysicsService")
local Players = game:GetService("Players")

local car = script.Parent
local playerGroupName = "Players"
local vehicleGroupName = "Vehicles"

local function checkGroupExists(groupName)
	local groups = PhysicsService:GetRegisteredCollisionGroups()
	for _, group in pairs(groups) do
		if group.name == groupName then
			return true
		end
	end
	return false
end

local function setCollisionGroupRecursive(object, groupName)
	if object and groupName then -- actually needed ty roblox for passing nil objects when they exist
		if object:IsA("BasePart") then
			object.CollisionGroup = groupName
		end

		for _, child in ipairs(object:GetChildren()) do
			setCollisionGroupRecursive(child, groupName)
		end
	end
end

Players.PlayerAdded:Connect(function(player)
	player.CharacterAdded:Connect(function(character)
		if character then -- ty roblox
			setCollisionGroupRecursive(character, playerGroupName)
		end
	end)
end)

local function setupCollisionGroups()
	task.wait(math.random(1, 3))

	if not checkGroupExists(playerGroupName) then
		PhysicsService:RegisterCollisionGroup(playerGroupName)
	end

	if not checkGroupExists(vehicleGroupName) then
		PhysicsService:RegisterCollisionGroup(vehicleGroupName)
	end
	
	PhysicsService:CollisionGroupSetCollidable(playerGroupName, vehicleGroupName, false)
	PhysicsService:CollisionGroupSetCollidable(playerGroupName, playerGroupName, false)
	PhysicsService:CollisionGroupSetCollidable(vehicleGroupName, vehicleGroupName, false)
	
	for _, player in pairs(Players:GetPlayers()) do
		local character = player.Character
		setCollisionGroupRecursive(character, playerGroupName)
	end

	setCollisionGroupRecursive(car, vehicleGroupName)
	
	car.DescendantAdded:Connect(function(descendant)
		setCollisionGroupRecursive(descendant, vehicleGroupName)
	end)
end

setupCollisionGroups()
